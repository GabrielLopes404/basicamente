<?php
session_start();

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'diamond_system');
define('BASE_URL', '/diamond_system/');

function db_connect() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $pdo = new PDO($dsn, DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        return $pdo;
    } catch (PDOException $e) {
        die("Erro de conexão: " . $e->getMessage());
    }
}

function db_close(&$conn) {
    $conn = null;
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function require_login() {
    if (!is_logged_in()) {
        redirect(BASE_URL . 'login.php');
    }
    
    if (isset($_SESSION['first_login']) && $_SESSION['first_login'] == 1) {
        $current_page = basename($_SERVER['PHP_SELF']);
        if ($current_page !== 'change_password.php' && $current_page !== 'logout.php') {
            redirect(BASE_URL . 'change_password.php');
        }
    }
}

function is_admin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

function is_manager() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'manager';
}

function is_seller() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'seller';
}

function can_manage_admins() {
    return is_admin();
}

function can_manage_products() {
    return is_admin() || is_manager();
}

function check_permission($roles = []) {
    if (!is_logged_in()) {
        redirect(BASE_URL . 'login.php');
    }
    
    if (!empty($roles) && !in_array($_SESSION['user_role'], $roles)) {
        display_error('Você não tem permissão para acessar esta página.');
        redirect(BASE_URL . 'dashboard.php');
    }
}

function require_user_permission() {
    check_permission(['admin', 'manager']);
}

function redirect($url) {
    header("Location: $url");
    exit;
}

function display_error($message) {
    $_SESSION['error_message'] = $message;
}

function display_success($message) {
    $_SESSION['success_message'] = $message;
}

function show_error() {
    if (isset($_SESSION['error_message'])) {
        echo '<div class="alert alert-danger alert-dismissible fade show position-fixed notification-alert notification-error" style="top: 24px; right: 24px; z-index: 10000; max-width: 500px; box-shadow: 0 10px 40px rgba(239, 68, 68, 0.3); border: 1px solid rgba(239, 68, 68, 0.4); animation: slideInDown 0.4s ease-out;" role="alert">';
        echo '<div style="padding-right: 30px;"><i class="fas fa-exclamation-circle me-2"></i>' . htmlspecialchars($_SESSION['error_message']) . '</div>';
        echo '<button type="button" class="btn-close btn-close-white position-absolute top-50 end-0 translate-middle-y me-2" data-bs-dismiss="alert" style="padding: 0.5rem;"></button>';
        echo '</div>';
        unset($_SESSION['error_message']);
    }
    
    if (isset($_SESSION['success_message'])) {
        echo '<div class="alert alert-success alert-dismissible fade show position-fixed notification-alert notification-success" style="top: 24px; right: 24px; z-index: 10000; max-width: 500px; box-shadow: 0 10px 40px rgba(16, 185, 129, 0.3); border: 1px solid rgba(16, 185, 129, 0.4); animation: slideInDown 0.4s ease-out;" role="alert">';
        echo '<div style="padding-right: 30px;"><i class="fas fa-check-circle me-2"></i>' . htmlspecialchars($_SESSION['success_message']) . '</div>';
        echo '<button type="button" class="btn-close btn-close-white position-absolute top-50 end-0 translate-middle-y me-2" data-bs-dismiss="alert" style="padding: 0.5rem;"></button>';
        echo '</div>';
        unset($_SESSION['success_message']);
    }
}

function format_money($value) {
    return 'R$ ' . number_format($value, 2, ',', '.');
}

function format_date($date) {
    return date('d/m/Y H:i', strtotime($date));
}

function validar_cpf($cpf) {
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    
    if (strlen($cpf) != 11) {
        return false;
    }
    
    if (preg_match('/(\d)\1{10}/', $cpf)) {
        return false;
    }
    
    for ($t = 9; $t < 11; $t++) {
        for ($d = 0, $c = 0; $c < $t; $c++) {
            $d += $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) {
            return false;
        }
    }
    return true;
}

function formatar_cpf($cpf) {
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    if (strlen($cpf) == 11) {
        return substr($cpf, 0, 3) . '.' . substr($cpf, 3, 3) . '.' . substr($cpf, 6, 3) . '-' . substr($cpf, 9, 2);
    }
    return $cpf;
}

function validar_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function validar_telefone($phone) {
    $phone = preg_replace('/[^0-9]/', '', $phone);
    return strlen($phone) == 10 || strlen($phone) == 11;
}

function formatar_telefone($phone) {
    $phone = preg_replace('/[^0-9]/', '', $phone);
    if (strlen($phone) == 11) {
        return '(' . substr($phone, 0, 2) . ') ' . substr($phone, 2, 5) . '-' . substr($phone, 7);
    } elseif (strlen($phone) == 10) {
        return '(' . substr($phone, 0, 2) . ') ' . substr($phone, 2, 4) . '-' . substr($phone, 6);
    }
    return $phone;
}

function validar_cep($cep) {
    $cep = preg_replace('/[^0-9]/', '', $cep);
    return strlen($cep) == 8;
}

function formatar_cep($cep) {
    $cep = preg_replace('/[^0-9]/', '', $cep);
    if (strlen($cep) == 8) {
        return substr($cep, 0, 5) . '-' . substr($cep, 5);
    }
    return $cep;
}

function upload_image($file) {
    $upload_dir = 'assets/uploads/products/';
    
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
    $max_size = 5 * 1024 * 1024;
    
    if (!in_array($file['type'], $allowed_types)) {
        display_error('Tipo de arquivo não permitido. Use JPEG, PNG ou GIF.');
        return null;
    }
    
    if ($file['size'] > $max_size) {
        display_error('Arquivo muito grande. Máximo 5MB.');
        return null;
    }
    
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid() . '.' . $extension;
    $filepath = $upload_dir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return $filename;
    }
    
    display_error('Erro ao fazer upload da imagem.');
    return null;
}

function get_role_badge($role) {
    $badges = [
        'admin' => '<span class="badge bg-danger">Administrador</span>',
        'manager' => '<span class="badge bg-primary">Gerente</span>',
        'seller' => '<span class="badge bg-info">Vendedor</span>'
    ];
    return $badges[$role] ?? '<span class="badge bg-secondary">Desconhecido</span>';
}

function csrf_field() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return '<input type="hidden" name="csrf_token" value="' . $_SESSION['csrf_token'] . '">';
}

function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function get_dashboard_stats($conn) {
    $stats = [];
    
    $stmt = $conn->query("SELECT COALESCE(SUM(total), 0) as total FROM sales WHERE DATE(sale_date) = CURDATE() AND status = 'concluída'");
    $stats['sales_today'] = $stmt->fetch()['total'];
    
    $stmt = $conn->query("SELECT COALESCE(SUM(total), 0) as total FROM sales WHERE MONTH(sale_date) = MONTH(CURDATE()) AND YEAR(sale_date) = YEAR(CURDATE()) AND status = 'concluída'");
    $stats['sales_month'] = $stmt->fetch()['total'];
    
    $stmt = $conn->query("SELECT COUNT(*) as total FROM clients");
    $stats['total_clients'] = $stmt->fetch()['total'];
    
    $stmt = $conn->query("SELECT COUNT(*) as total FROM products WHERE stock <= 5");
    $stats['low_stock'] = $stmt->fetch()['total'];
    
    return $stats;
}

function get_chart_data($conn) {
    $data = [];
    
    $stmt = $conn->query("
        SELECT DATE(sale_date) as date, COALESCE(SUM(total), 0) as total
        FROM sales
        WHERE sale_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND status = 'concluída'
        GROUP BY DATE(sale_date)
        ORDER BY date ASC
    ");
    $data['sales_week'] = $stmt->fetchAll();
    
    $stmt = $conn->query("
        SELECT c.name as category, COALESCE(SUM(si.subtotal), 0) as total
        FROM categories c
        LEFT JOIN products p ON c.id = p.category_id
        LEFT JOIN sale_items si ON p.id = si.product_id
        LEFT JOIN sales s ON si.sale_id = s.id AND s.status = 'concluída'
        GROUP BY c.id, c.name
        HAVING total > 0
        ORDER BY total DESC
        LIMIT 5
    ");
    $data['sales_by_category'] = $stmt->fetchAll();
    
    return $data;
}

function buscar_cep($cep) {
    $cep = preg_replace('/[^0-9]/', '', $cep);
    
    if (strlen($cep) != 8) {
        return ['erro' => true, 'mensagem' => 'CEP inválido'];
    }
    
    $url = "https://viacep.com.br/ws/{$cep}/json/";
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    curl_close($ch);
    
    if ($response === false) {
        return ['erro' => true, 'mensagem' => 'Erro ao consultar CEP'];
    }
    
    $data = json_decode($response, true);
    
    if (isset($data['erro']) && $data['erro']) {
        return ['erro' => true, 'mensagem' => 'CEP não encontrado'];
    }
    
    return $data;
}
