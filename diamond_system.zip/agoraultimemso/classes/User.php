<?php
class User {
    private $conn;
    private $table = 'users';
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    public function authenticate($username, $password) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE username = :username LIMIT 1");
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_username'] = $user['username'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['first_login'] = $user['first_login'];
            return true;
        }
        return false;
    }
    
    public function create($name, $username, $password, $email, $role) {
        $stmt = $this->conn->prepare("SELECT id FROM {$this->table} WHERE username = :username");
        $stmt->execute(['username' => $username]);
        
        if ($stmt->fetch()) {
            return false;
        }
        
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $this->conn->prepare("INSERT INTO {$this->table} (name, username, password, email, role, first_login) VALUES (:name, :username, :password, :email, :role, 1)");
        
        return $stmt->execute([
            'name' => $name,
            'username' => $username,
            'password' => $password_hash,
            'email' => $email,
            'role' => $role
        ]);
    }
    
    public function update($id, $name, $username, $email, $role, $password = '') {
        if (!empty($password)) {
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $this->conn->prepare("UPDATE {$this->table} SET name = :name, username = :username, email = :email, role = :role, password = :password WHERE id = :id");
            return $stmt->execute([
                'name' => $name,
                'username' => $username,
                'email' => $email,
                'role' => $role,
                'password' => $password_hash,
                'id' => $id
            ]);
        } else {
            $stmt = $this->conn->prepare("UPDATE {$this->table} SET name = :name, username = :username, email = :email, role = :role WHERE id = :id");
            return $stmt->execute([
                'name' => $name,
                'username' => $username,
                'email' => $email,
                'role' => $role,
                'id' => $id
            ]);
        }
    }
    
    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM {$this->table} WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
    
    public function getAll() {
        $stmt = $this->conn->query("SELECT * FROM {$this->table} ORDER BY created_at DESC");
        return $stmt->fetchAll();
    }
    
    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id = :id LIMIT 1");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }
    
    public function updatePassword($id, $new_password) {
        $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET password = :password, first_login = 0 WHERE id = :id");
        return $stmt->execute(['password' => $password_hash, 'id' => $id]);
    }
    
    public function getByEmail($email) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE email = :email LIMIT 1");
        $stmt->execute(['email' => $email]);
        return $stmt->fetch();
    }
    
    public function createPasswordResetToken($user_id) {
        $token = bin2hex(random_bytes(32));
        $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        $stmt = $this->conn->prepare("INSERT INTO password_resets (user_id, token, expires_at) VALUES (:user_id, :token, :expires_at)");
        
        if ($stmt->execute(['user_id' => $user_id, 'token' => $token, 'expires_at' => $expires_at])) {
            return $token;
        }
        return false;
    }
    
    public function validateResetToken($token) {
        $stmt = $this->conn->prepare("SELECT pr.*, u.* FROM password_resets pr JOIN {$this->table} u ON pr.user_id = u.id WHERE pr.token = :token AND pr.expires_at > NOW() AND pr.used = 0 LIMIT 1");
        $stmt->execute(['token' => $token]);
        return $stmt->fetch();
    }
    
    public function resetPassword($token, $new_password) {
        $user_data = $this->validateResetToken($token);
        
        if (!$user_data) {
            return false;
        }
        
        $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
        
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET password = :password WHERE id = :id");
        $updated = $stmt->execute(['password' => $password_hash, 'id' => $user_data['user_id']]);
        
        if ($updated) {
            $stmt = $this->conn->prepare("UPDATE password_resets SET used = 1 WHERE token = :token");
            $stmt->execute(['token' => $token]);
        }
        
        return $updated;
    }
}
?>
