<?php
class Client {
    private $conn;
    private $table = 'clients';
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    public function create($name, $cpf, $email, $phone, $address, $city, $state, $postal_code) {
        $stmt = $this->conn->prepare("INSERT INTO {$this->table} (name, cpf, email, phone, address, city, state, postal_code) VALUES (:name, :cpf, :email, :phone, :address, :city, :state, :postal_code)");
        
        return $stmt->execute([
            'name' => $name,
            'cpf' => $cpf,
            'email' => $email,
            'phone' => $phone,
            'address' => $address,
            'city' => $city,
            'state' => $state,
            'postal_code' => $postal_code
        ]);
    }
    
    public function update($id, $name, $cpf, $email, $phone, $address, $city, $state, $postal_code) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET name = :name, cpf = :cpf, email = :email, phone = :phone, address = :address, city = :city, state = :state, postal_code = :postal_code WHERE id = :id");
        
        return $stmt->execute([
            'name' => $name,
            'cpf' => $cpf,
            'email' => $email,
            'phone' => $phone,
            'address' => $address,
            'city' => $city,
            'state' => $state,
            'postal_code' => $postal_code,
            'id' => $id
        ]);
    }
    
    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM {$this->table} WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
    
    public function getAll() {
        $stmt = $this->conn->query("SELECT * FROM {$this->table} ORDER BY name ASC");
        return $stmt->fetchAll();
    }
    
    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM {$this->table} WHERE id = :id LIMIT 1");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }
}
?>
