<?php
class Product {
    private $conn;
    private $table = 'products';
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    public function create($name, $description, $category_id, $price, $cost, $stock, $image = null) {
        $stmt = $this->conn->prepare("INSERT INTO {$this->table} (name, description, category_id, price, cost, stock, image) VALUES (:name, :description, :category_id, :price, :cost, :stock, :image)");
        
        return $stmt->execute([
            'name' => $name,
            'description' => $description,
            'category_id' => $category_id,
            'price' => $price,
            'cost' => $cost,
            'stock' => $stock,
            'image' => $image
        ]);
    }
    
    public function update($id, $name, $description, $category_id, $price, $cost, $stock, $image = null) {
        if ($image) {
            $stmt = $this->conn->prepare("UPDATE {$this->table} SET name = :name, description = :description, category_id = :category_id, price = :price, cost = :cost, stock = :stock, image = :image WHERE id = :id");
            return $stmt->execute([
                'name' => $name,
                'description' => $description,
                'category_id' => $category_id,
                'price' => $price,
                'cost' => $cost,
                'stock' => $stock,
                'image' => $image,
                'id' => $id
            ]);
        } else {
            $stmt = $this->conn->prepare("UPDATE {$this->table} SET name = :name, description = :description, category_id = :category_id, price = :price, cost = :cost, stock = :stock WHERE id = :id");
            return $stmt->execute([
                'name' => $name,
                'description' => $description,
                'category_id' => $category_id,
                'price' => $price,
                'cost' => $cost,
                'stock' => $stock,
                'id' => $id
            ]);
        }
    }
    
    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM {$this->table} WHERE id = :id");
        return $stmt->execute(['id' => $id]);
    }
    
    public function getAll() {
        $stmt = $this->conn->query("SELECT p.*, c.name as category_name FROM {$this->table} p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.created_at DESC");
        return $stmt->fetchAll();
    }
    
    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT p.*, c.name as category_name FROM {$this->table} p LEFT JOIN categories c ON p.category_id = c.id WHERE p.id = :id LIMIT 1");
        $stmt->execute(['id' => $id]);
        return $stmt->fetch();
    }
    
    public function getCategories() {
        $stmt = $this->conn->query("SELECT * FROM categories ORDER BY name ASC");
        return $stmt->fetchAll();
    }
    
    public function getLowStock($threshold = 5) {
        $stmt = $this->conn->prepare("SELECT p.*, c.name as category_name FROM {$this->table} p LEFT JOIN categories c ON p.category_id = c.id WHERE p.stock <= :threshold ORDER BY p.stock ASC");
        $stmt->execute(['threshold' => $threshold]);
        return $stmt->fetchAll();
    }
    
    public function getVitrineProducts() {
        $stmt = $this->conn->query("SELECT p.*, c.name as category_name FROM {$this->table} p LEFT JOIN categories c ON p.category_id = c.id WHERE p.stock > 0 ORDER BY p.created_at DESC");
        return $stmt->fetchAll();
    }
    
    public function updateStock($id, $quantity) {
        $stmt = $this->conn->prepare("UPDATE {$this->table} SET stock = stock - :quantity WHERE id = :id");
        return $stmt->execute(['quantity' => $quantity, 'id' => $id]);
    }
}
?>
