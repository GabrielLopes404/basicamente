<?php
require_once 'config/config.php';
require_once 'classes/Sale.php';

require_login();

$conn = db_connect();
$sale = new Sale($conn);

$action = $_GET['action'] ?? 'list';
$id = (int)($_GET['id'] ?? 0);

if ($action === 'delete' && $id > 0) {
    if (!is_admin() && !is_manager()) {
        display_error('Você não tem permissão para excluir vendas.');
        redirect(BASE_URL . 'sales.php');
    }
    
    if ($sale->delete($id)) {
        display_success('Venda excluída com sucesso!');
    } else {
        display_error('Erro ao excluir venda.');
    }
    redirect(BASE_URL . 'sales.php');
}

$sales = $sale->getAll();
$page_title = 'Vendas';

require_once 'includes/header.php';
require_once 'includes/sidebar.php';
?>

<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-shopping-cart me-2"></i>Gerenciar Vendas</h1>
    <div class="btn-toolbar mb-2">
        <a href="new_sale.php" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i> Nova Venda
        </a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Cliente</th>
                        <th>Vendedor</th>
                        <th>Data</th>
                        <th>Total</th>
                        <th>Pagamento</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($sales)): ?>
                        <?php foreach ($sales as $s): ?>
                            <tr>
                                <td>#<?php echo $s['id']; ?></td>
                                <td><?php echo htmlspecialchars($s['client_name'] ?: 'Não registrado'); ?></td>
                                <td><?php echo htmlspecialchars($s['user_name'] ?: 'N/A'); ?></td>
                                <td><?php echo format_date($s['sale_date']); ?></td>
                                <td><?php echo format_money($s['total']); ?></td>
                                <td><?php echo htmlspecialchars($s['payment_method']); ?></td>
                                <td>
                                    <?php if ($s['status'] == 'concluída'): ?>
                                        <span class="badge bg-success">Concluída</span>
                                    <?php elseif ($s['status'] == 'cancelada'): ?>
                                        <span class="badge bg-danger">Cancelada</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">Pendente</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="sale_detail.php?id=<?php echo $s['id']; ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <?php if (is_admin() || is_manager()): ?>
                                    <a href="?action=delete&id=<?php echo $s['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Tem certeza que deseja excluir esta venda?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted">Nenhuma venda registrada.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php
db_close($conn);
require_once 'includes/footer.php';
?>
