<?php
require_once 'config/config.php';
require_once 'classes/User.php';

require_user_permission();

$conn = db_connect();
$user = new User($conn);

$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'] ?? '';
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $role = $_POST['role'] ?? 'seller';
    $password = $_POST['password'] ?? '';
    
    if ($action == 'create') {
        if ($user->create($name, $username, $password, $email, $role)) {
            display_success('Usuário cadastrado com sucesso!');
            redirect(BASE_URL . 'users.php');
        } else {
            display_error('Erro ao cadastrar usuário.');
        }
    } elseif ($action == 'edit' && $id > 0) {
        if ($user->update($id, $name, $username, $email, $role, $password)) {
            display_success('Usuário atualizado com sucesso!');
            redirect(BASE_URL . 'users.php');
        } else {
            display_error('Erro ao atualizar usuário.');
        }
    }
}

if ($action == 'delete' && $id > 0) {
    if ($user->delete($id)) {
        display_success('Usuário excluído com sucesso!');
    } else {
        display_error('Erro ao excluir usuário.');
    }
    redirect(BASE_URL . 'users.php');
}

$users = $user->getAll();
$page_title = 'Usuários';

require_once 'includes/header.php';
require_once 'includes/sidebar.php';
?>

<?php if ($action == 'list'): ?>
<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-user-shield me-2"></i>Gerenciar Usuários</h1>
    <div class="btn-toolbar mb-2">
        <a href="?action=create" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i> Novo Usuário
        </a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>Usuário</th>
                        <th>Email</th>
                        <th>Perfil</th>
                        <th>Data de Cadastro</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $u): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($u['name']); ?></td>
                        <td><?php echo htmlspecialchars($u['username']); ?></td>
                        <td><?php echo htmlspecialchars($u['email']); ?></td>
                        <td><?php echo get_role_badge($u['role']); ?></td>
                        <td><?php echo format_date($u['created_at']); ?></td>
                        <td>
                            <?php if ($u['role'] !== 'admin' || can_manage_admins()): ?>
                            <a href="?action=edit&id=<?php echo $u['id']; ?>" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-edit"></i>
                            </a>
                            <?php endif; ?>
                            
                            <?php if ($u['id'] != $_SESSION['user_id'] && ($u['role'] !== 'admin' || can_manage_admins())): ?>
                            <a href="?action=delete&id=<?php echo $u['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Tem certeza que deseja excluir este usuário?')">
                                <i class="fas fa-trash"></i>
                            </a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php elseif ($action == 'create' || $action == 'edit'): ?>
<?php
$current_user = null;
if ($action == 'edit' && $id > 0) {
    $current_user = $user->getById($id);
    if (!$current_user) {
        display_error('Usuário não encontrado.');
        redirect(BASE_URL . 'users.php');
    }
    
    if ($current_user['role'] === 'admin' && !can_manage_admins()) {
        display_error('Você não tem permissão para editar usuários administradores.');
        redirect(BASE_URL . 'users.php');
    }
}
?>

<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo $action == 'create' ? 'Novo Usuário' : 'Editar Usuário'; ?></h1>
    <div class="btn-toolbar mb-2">
        <a href="users.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    </div>
</div>

<form method="post">
    <div class="row justify-content-center">
        <div class="col-md-10 col-lg-8">
            <div class="card mb-4">
                <div class="card-header">Informações do Usuário</div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="name" class="form-label">Nome Completo</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($current_user['name'] ?? ''); ?>" required>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="username" class="form-label">Nome de Usuário</label>
                            <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($current_user['username'] ?? ''); ?>" required>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($current_user['email'] ?? ''); ?>">
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="role" class="form-label">Perfil</label>
                            <select class="form-select" id="role" name="role" required>
                                <option value="seller" <?php echo ($current_user['role'] ?? 'seller') == 'seller' ? 'selected' : ''; ?>>Vendedor</option>
                                <option value="manager" <?php echo ($current_user['role'] ?? '') == 'manager' ? 'selected' : ''; ?>>Gerente</option>
                                <?php if (can_manage_admins()): ?>
                                <option value="admin" <?php echo ($current_user['role'] ?? '') == 'admin' ? 'selected' : ''; ?>>Administrador</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">
                            <?php echo $action == 'create' ? 'Senha' : 'Nova Senha (deixe em branco para manter a atual)'; ?>
                        </label>
                        <div class="input-group">
                            <input type="password" class="form-control" id="password" name="password" <?php echo $action == 'create' ? 'required' : ''; ?>>
                            <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                                <i class="fas fa-eye" id="eyeIcon"></i>
                            </button>
                        </div>
                    </div>
                    
                    <script>
                    document.getElementById('togglePassword').addEventListener('click', function() {
                        const passwordInput = document.getElementById('password');
                        const eyeIcon = document.getElementById('eyeIcon');
                        
                        if (passwordInput.type === 'password') {
                            passwordInput.type = 'text';
                            eyeIcon.classList.remove('fa-eye');
                            eyeIcon.classList.add('fa-eye-slash');
                        } else {
                            passwordInput.type = 'password';
                            eyeIcon.classList.remove('fa-eye-slash');
                            eyeIcon.classList.add('fa-eye');
                        }
                    });
                    </script>
                    
                    <div class="card" style="background: rgba(6, 182, 212, 0.05); border-color: rgba(6, 182, 212, 0.2);">
                        <div class="card-body">
                            <strong><i class="fas fa-info-circle me-2"></i>Permissões dos Perfis:</strong>
                            <ul class="mb-0 mt-2">
                                <li><strong>Vendedor:</strong> Adiciona vendas e clientes (visualiza produtos)</li>
                                <li><strong>Gerente:</strong> Gerencia produtos, vendas, clientes e usuários (exceto admins)</li>
                                <?php if (can_manage_admins()): ?>
                                <li><strong>Administrador:</strong> Acesso total ao sistema</li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="d-grid">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-save me-2"></i>Salvar Usuário
                </button>
            </div>
        </div>
    </div>
</form>
<?php endif; ?>

<?php
db_close($conn);
require_once 'includes/footer.php';
?>
