<?php
require_once 'config/config.php';
require_once 'classes/Client.php';

require_login();

$conn = db_connect();
$client = new Client($conn);

$action = $_GET['action'] ?? 'list';
$id = $_GET['id'] ?? 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'] ?? '';
    $cpf = preg_replace('/[^0-9]/', '', $_POST['cpf'] ?? '');
    $email = $_POST['email'] ?? '';
    $phone = preg_replace('/[^0-9]/', '', $_POST['phone'] ?? '');
    $address = $_POST['address'] ?? '';
    $city = $_POST['city'] ?? '';
    $state = $_POST['state'] ?? '';
    $postal_code = preg_replace('/[^0-9]/', '', $_POST['postal_code'] ?? '');
    
    if ($action == 'create') {
        if ($client->create($name, $cpf, $email, $phone, $address, $city, $state, $postal_code)) {
            display_success('Cliente cadastrado com sucesso!');
            redirect(BASE_URL . 'clients.php');
        } else {
            display_error('Erro ao cadastrar cliente.');
        }
    } elseif ($action == 'edit' && $id > 0) {
        if ($client->update($id, $name, $cpf, $email, $phone, $address, $city, $state, $postal_code)) {
            display_success('Cliente atualizado com sucesso!');
            redirect(BASE_URL . 'clients.php');
        } else {
            display_error('Erro ao atualizar cliente.');
        }
    }
}

if ($action == 'delete' && $id > 0) {
    if ($client->delete($id)) {
        display_success('Cliente excluído com sucesso!');
    } else {
        display_error('Erro ao excluir cliente.');
    }
    redirect(BASE_URL . 'clients.php');
}

$clients = $client->getAll();
$page_title = 'Clientes';

require_once 'includes/header.php';
require_once 'includes/sidebar.php';
?>

<?php if ($action == 'list'): ?>
<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><i class="fas fa-users me-2"></i>Gerenciar Clientes</h1>
    <div class="btn-toolbar mb-2">
        <a href="?action=create" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i> Novo Cliente
        </a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>CPF</th>
                        <th>Email</th>
                        <th>Telefone</th>
                        <th>Cidade</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($clients as $c): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($c['name']); ?></td>
                        <td><?php echo formatar_cpf($c['cpf']); ?></td>
                        <td><?php echo htmlspecialchars($c['email']); ?></td>
                        <td><?php echo formatar_telefone($c['phone']); ?></td>
                        <td><?php echo htmlspecialchars($c['city'] . '/' . $c['state']); ?></td>
                        <td>
                            <a href="?action=edit&id=<?php echo $c['id']; ?>" class="btn btn-sm btn-outline-primary">
                                <i class="fas fa-edit"></i>
                            </a>
                            <a href="?action=delete&id=<?php echo $c['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Tem certeza que deseja excluir este cliente?')">
                                <i class="fas fa-trash"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php elseif ($action == 'create' || $action == 'edit'): ?>
<?php
$current_client = null;
if ($action == 'edit' && $id > 0) {
    $current_client = $client->getById($id);
    if (!$current_client) {
        display_error('Cliente não encontrado.');
        redirect(BASE_URL . 'clients.php');
    }
}
?>

<div class="d-flex justify-content-between flex-wrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2"><?php echo $action == 'create' ? 'Novo Cliente' : 'Editar Cliente'; ?></h1>
    <div class="btn-toolbar mb-2">
        <a href="clients.php" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-1"></i> Voltar
        </a>
    </div>
</div>

<form method="post">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card mb-4">
                <div class="card-header">Informações do Cliente</div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="name" class="form-label">Nome Completo</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($current_client['name'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="cpf" class="form-label">CPF</label>
                            <input type="text" class="form-control cpf-input" id="cpf" name="cpf" value="<?php echo formatar_cpf($current_client['cpf'] ?? ''); ?>" required>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($current_client['email'] ?? ''); ?>">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="phone" class="form-label">Telefone</label>
                            <input type="text" class="form-control phone-input" id="phone" name="phone" value="<?php echo formatar_telefone($current_client['phone'] ?? ''); ?>" required>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="postal_code" class="form-label">CEP</label>
                            <div class="input-group">
                                <input type="text" class="form-control cep-input" id="postal_code" name="postal_code" value="<?php echo formatar_cep($current_client['postal_code'] ?? ''); ?>" required>
                                <button type="button" class="btn btn-outline-primary" id="btn-buscar-cep">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="address" class="form-label">Endereço</label>
                        <input type="text" class="form-control" id="address" name="address" value="<?php echo htmlspecialchars($current_client['address'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-8 mb-3">
                            <label for="city" class="form-label">Cidade</label>
                            <input type="text" class="form-control" id="city" name="city" value="<?php echo htmlspecialchars($current_client['city'] ?? ''); ?>" required>
                        </div>
                        
                        <div class="col-md-4 mb-3">
                            <label for="state" class="form-label">Estado (UF)</label>
                            <input type="text" class="form-control" id="state" name="state" value="<?php echo htmlspecialchars($current_client['state'] ?? ''); ?>" maxlength="2" required>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="d-grid">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-save me-2"></i>Salvar Cliente
                </button>
            </div>
        </div>
    </div>
</form>
<?php endif; ?>

<?php
db_close($conn);
require_once 'includes/footer.php';
?>
